//
//  MGConnectFramework.h
//  MGConnectFramework
//
//  Created by Shimon Shnitzer on 05/01/2025.
//

#import <Foundation/Foundation.h>

//#import <BLEInterface/BLEInterface.h>

//! Project version number for MGConnectFramework.
FOUNDATION_EXPORT double MGConnectFrameworkVersionNumber;

//! Project version string for MGConnectFramework.
FOUNDATION_EXPORT const unsigned char MGConnectFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MGConnectFramework/PublicHeader.h>


